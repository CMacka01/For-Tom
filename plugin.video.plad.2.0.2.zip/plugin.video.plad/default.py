# -*- coding: utf-8 -*-
import ssl
import urllib.request
import urllib.error
from urllib.parse import urlparse
import datetime
import time
import re
import os
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import base64
import gzip
from bs4 import BeautifulStoneSoup, BeautifulSoup
try:
    import json
except:
    import simplejson as json

addon = xbmcaddon.Addon('plugin.video.plad')
addon_version = addon.getAddonInfo('version')
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
home = xbmcvfs.translatePath(addon.getAddonInfo('path'))
REV = os.path.join(profile, 'list_revision')
icon = os.path.join(home, 'icon.png')
FANART = os.path.join(home, 'fanart.jpg')
debug = addon.getSetting('debug')
PADLuser = addon.getSetting('PADLusername')
PADLpass = addon.getSetting('PADLpassword')
cookieDetails = addon.getSetting('cookieDetails')
PLADDir = 'https://gonna.mobi/premium/wp/epg/'
PLADVar = '?wmsAuthSign='


def addon_log(string):
    if debug == 'true':
        xbmc.log("[addon.plad.log-%s]: %s" %(addon_version, string))


def makeRequest(url, postdata=None, webcookie=None, urlmethod='GET', savecookie=None):
    addon_log("makeRequest URL - " + url)
    cookieDetails = addon.getSetting('cookieDetails')
    try:
        context = ssl._create_unverified_context()  # <-- Ignore SSL certificate verification

        if postdata is not None:
            req = urllib.request.Request(url, data=postdata, method=urlmethod)
        else:
            req = urllib.request.Request(url, method=urlmethod)

        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0')
        req.add_header('Host', 'gonna.mobi')
        req.add_header('Accept', '*/*')
        req.add_header('Accept-Language', 'en-GB,en;q=0.5')
        req.add_header('Accept-Encoding', 'gzip, deflate')
        if urlmethod == 'POST':
            req.add_header('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
            req.add_header('X-Requested-With', 'XMLHttpRequest')
        req.add_header('Referer', 'https://gonna.mobi/amember/login')

        if webcookie is None:
            if cookieDetails is not None:
                addon_log("Using cookieDetails header " + cookieDetails)
                req.add_header('Cookie', cookieDetails)
        else:
            addon_log("Using webcookie header " + webcookie)
            req.add_header('Cookie', webcookie)

        response = urllib.request.urlopen(req, context=context)

        cookie = None
        headerlist = str(response.headers).splitlines()
        for headerline in headerlist:
            if "amember" in headerline:
                cookie = headerline.replace('Set-Cookie: ', '')
                addon_log("Found new correct Set-Cookie: " + cookie)
        if cookie is not None:
            if savecookie is not None:
                addon_log("Writing this value to cookieDetails setting: " + cookie)
                addon.setSetting('cookieDetails', cookie)

        content_encoding = response.headers.get('Content-Encoding')
        addon_log(str(content_encoding))
        if content_encoding == 'gzip':
            data = gzip.decompress(response.read()).decode()
        else:
            data = response.read().decode(response.headers.get_content_charset())
        addon_log(data)
        response.close()
        return data

    except urllib.error.URLError as e:
        addon_log('URL: ' + url)
        if hasattr(e, 'code'):
            if e.code == '302':
                return 'redirect'
            addon_log('We failed with error code - %s.' % e.code)
            xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed with error code - " + str(e.code) + ",10000," + icon + ")")
        elif hasattr(e, 'reason'):
            addon_log('We failed to reach a server.')
            addon_log('Reason: %s' % e.reason)
            xbmc.executebuiltin("XBMC.Notification(LiveStreams,We failed to reach a server. - " + str(e.reason) + ",10000," + icon + ")")

def get_xml_database(url, cookieInfo, browse=False):
        addon_log('get xml using cookie - '+cookieInfo)
        if url is None:
            url = PLADDir
        requestpage = makeRequest(url, postdata=None, webcookie=cookieInfo, urlmethod='GET', savecookie=None)
        addon_log(requestpage)
        if requestpage is not None:
            soup = BeautifulSoup(requestpage, 'html.parser')
        if soup is not None:
          for link in soup.find_all('a'):
              href = link.get('href')
              if not href.startswith('?'):
                  name = link.string
                  addon_log(name)
                  if name not in ['Parent Directory', 'recycle_bin/']:
                      if href.endswith('/'):
                          if browse:
                              addDir(name,url+href,15,icon,fanart,'','','')
                              addon_log("Added "+name+" with "+url+href)
                          else:
                              addDir(name,url+href,14,icon,fanart,'','','')
                              addon_log("Added "+name+" with "+url+href)
                      elif href.endswith('.xml'):
                          if browse:
                              addDir(name,url+href,1,icon,fanart,'','','','')
                              addon_log("Added "+name+" with "+url+href)
                          else:
                              addDir(name,url+href,11,icon,fanart,'','','','')
                              addon_log("Added "+name+" with "+url+href)

def getSoup(url):
        if url.startswith('https://'):
            data = makeRequest(url)
        else:
            if xbmcvfs.exists(url):
                if url.startswith("smb://") or url.startswith("nfs://"):
                    copy = xbmcvfs.copy(url, os.path.join(profile, 'temp', 'sorce_temp.txt'))
                    if copy:
                        data = open(os.path.join(profile, 'temp', 'sorce_temp.txt'), "r").read()
                        xbmcvfs.delete(os.path.join(profile, 'temp', 'sorce_temp.txt'))
                    else:
                        addon_log("failed to copy from smb:")
                else:
                    data = open(url, 'r').read()
            else:
                addon_log("Soup Data not found!")
                return
        return BeautifulSoup(data, "html.parser")


def getData(url,fanart):
        addon_log('Get Soup: '+url)
        soup = getSoup(url)
        getItems(soup('item'),fanart)


def getItems(items,fanart):
        total = len(items)
        addon_log('Total Items: %s' %total)
        for item in items:
            try:
                name = item('title')[0].string
                addon_log('Found item with name '+name)
                if name is None:
                    name = 'unknown?'
            except:
                addon_log('Name Error')
                name = ''
            try:
                url = []
                for i in item('link'):
                    if not i.string == None:
                        url.append(i.string)
                if len(url) < 1:
                    for z in item.children:
                        if str(z).strip().endswith('m3u8'):
                            url.append(str(z).strip())
                if len(url) < 1:
                    raise
            except:
                addon_log('Error <link> element, Passing:'+name)
                continue

            try:
                thumbnail = item('thumbnail')[0].string
                if thumbnail == None:
                    raise
            except:
                thumbnail = ''
            try:
                if not item('fanart'):
                    if addon.getSetting('use_thumb') == "true":
                        fanArt = thumbnail
                    else:
                        fanArt = fanart
                else:
                    fanArt = item('fanart')[0].string
                if fanArt == None:
                    raise
            except:
                fanArt = fanart
            try:
                desc = item('epgdata')[0].string
                desc = desc.replace('/NL/', '\n')
                if desc == None:
                    raise
            except:
                desc = 'No Games Scheduled'
            try:
                genre = item('genre')[0].string
                if genre == None:
                    raise
            except:
                genre = 'Sport'

            try:
                date = item('date')[0].string
                if date == None:
                    raise
            except:
                date = '2021'

            try:
                if len(url) > 1:
                    alt = 0
                    for i in url:
                        alt += 1
                        addLink(i,'%s) %s' %(alt, name.encode('utf-8', 'ignore')),thumbnail,fanArt,desc,genre,date,total)
                else:
                    addLink(url[0],name.encode('utf-8', 'ignore'),thumbnail,fanArt,desc,genre,date,total)
            except:
                addon_log('There was a problem adding item - '+name.encode('utf-8', 'ignore'))


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                splitparams={}
                splitparams=pairsofparams[i].split('=')
                if (len(splitparams))==2:
                    param[splitparams[0]]=splitparams[1]
        return param

def addDir(name,url,mode,iconimage,fanart,description,genre,date,credits):
        addon_log("trying to add item to menu")
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&fanart="+urllib.parse.quote_plus(fanart)
        ok=True
        if date == '':
            date = None
        else:
            description += '\n\nDate: %s' %date
        liz=xbmcgui.ListItem(name)
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "dateadded": date, "credits": credits })
        if iconimage is not None:
            liz.setArt({ "thumb": iconimage, "icon": iconimage })
        liz.setProperty("Fanart_Image", fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def addLink(url,name,iconimage,fanart,description,genre,date,total):
        try:
            name = name.encode('utf-8')
        except: pass
        ok = True
        mode = '12'
        u=sys.argv[0]+"?"
        u += "url="+urllib.parse.quote_plus(url)+"&mode="+mode
        liz=xbmcgui.ListItem(name)
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "dateadded": date })
        if iconimage is not None:
            liz.setArt({ "thumb": iconimage, "icon": iconimage })
        liz.setProperty("Fanart_Image", fanart)
        liz.setProperty('IsPlayable', 'true')
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,totalItems=total)
        return ok

def getADauth():

        URL_LOGIN = 'https://gonna.mobi/amember/login'
        addon_log("Logging in as "+PADLuser)
        datalogin = urllib.parse.urlencode({
          'amember_login' : PADLuser,
          'amember_pass': PADLpass
        })
        
        datalogin = datalogin.encode('ascii')
        addon.setSetting('cookieDetails', '')
        response = makeRequest(URL_LOGIN, postdata=datalogin, webcookie=None, urlmethod='POST', savecookie='yes')
        successMsg = re.search('"ok":true', response)
        if successMsg is None:
            addon_log("login failure")
            return 'Error'
        else:
            addon_log("login successful")
            return 'Success'
        
        
def getHash(cookie):

        URL_AUTH = 'https://gonna.mobi/premium/wp/epg/?hash=on'
        try:
          response = makeRequest(URL_AUTH, postdata=None, webcookie=cookie, urlmethod='GET', savecookie=None)
        except urllib.error.HTTPError as ex:
          return 'Error'
        if response is None:
          return 'Error'
        errorMsg = re.search('Please login', response)
        if errorMsg is not None:
          return 'Error'
        if response.endswith('='):
          cleanResult = response
        else:
          cleanResult = response+'='
        decodedHash = base64.b64decode(cleanResult).decode('utf-8')
        addon_log("decoded hash is "+decodedHash)
        if decodedHash.startswith('server_time='):
          return response
        else:
          return 'Error'
        
def detailsPrompt():
      xbmcgui.Dialog().ok("Problem logging in", "Check Username and Password")
      addon.openSettings()
      xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
      xbmc.executebuiltin("XBMC.ActivateWindow(Videos,addons://sources/video)")
      
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_GENRE)
except:
    pass

params=get_params()

url=None
name=None
mode=None
playlist=None
iconimage=None
fanart=FANART
playlist=None
fav_mode=None
regexs=None

addon_log("Mode: "+str(mode))
addon_log("Params: "+str(params))

try:
    addon_log(params["url"])
    url=urllib.parse.unquote_plus(params["url"])
except:
    addon_log("No URL found")
    pass
try:
    name=urllib.parse.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
    pass
try:
    fanart=urllib.parse.unquote_plus(params["fanart"])
except:
    pass
try:
    mode=int(params["mode"])
except:
    pass
try:
    playlist=eval(urllib.parse.unquote_plus(params["playlist"]).replace('|',','))
except:
    pass
try:
    fav_mode=int(params["fav_mode"])
except:
    pass
try:
    regexs=params["regexs"]
except:
    pass

if not url is None:
    addon_log("URL: "+str(url.encode('utf-8')))
addon_log("Name: "+str(name))

addon_log("Checking username and password have been set")

if PADLuser == '':
  detailsPrompt()
if PADLuser == None:
  detailsPrompt()
PADLuser = addon.getSetting('PADLusername')
PADLpass = addon.getSetting('PADLpassword')

if PADLpass == '':
  detailsPrompt()
if PADLpass == None:
  detailsPrompt()
PADLpass = addon.getSetting('PADLpassword')

addon_log("Checking cookie is set and valid")

if cookieDetails == '':
  addon_log("cookieDetails is empty")
  getADauth()
if cookieDetails == None:
  addon_log("cookieDetails is None")
  getADauth()

if cookieDetails == 'Error':
  addon_log("cookieDetails is Error")
  detailsPrompt()

addon_log("Trying to get hash")
cookieDetails = addon.getSetting('cookieDetails')
getHashCode = getHash(cookieDetails)

if getHashCode == 'Error':
  addon_log("Error retrieving hash - trying to login again")
  retryEffort = getADauth()
  if retryEffort == 'Error':
    addon_log("failed to login - asking for username and password")
    detailsPrompt()
  else:
    cookieDetails = addon.getSetting('cookieDetails')
    addon_log("new cookie is - "+cookieDetails)
    getHashCode = getHash(cookieDetails)
    addon_log("hash retrieved - "+getHashCode)


finalHash = getHashCode

if mode==None:
    addon_log("Getting XML links from PLAD")
    get_xml_database(PLADDir, cookieDetails, True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==1:
    addon_log("getData url- "+url)
    getData(url,fanart)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==12:
    addon_log("playing URL - "+url)
    item = xbmcgui.ListItem(path=url+PLADVar+finalHash)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

elif mode==14:
    addon_log("get_xml_database")
    get_xml_database(url)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode==15:
    addon_log("browse_xml_database")
    get_xml_database(url, cookieDetails, True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))